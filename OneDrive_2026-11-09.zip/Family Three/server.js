const express = require('express');
const nodemailer = require('nodemailer');
const cors = require('cors');
const bodyParser = require('body-parser');

const app = express();
app.use(cors());
app.use(bodyParser.json());

// Configure Nodemailer with your real Gmail account
// Note: For Gmail, you should use an "App Password", not your normal login password.
const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        user: 'your-real-email@gmail.com',         // Replace with your Gmail
        pass: 'your-gmail-app-password'             // Replace with your 16-digit Gmail App Password
    }
});

// Store users temporarily (In a real app, use a database like MongoDB or SQL)
let pendingUsers = [];

// Registration Route
app.post('/api/register', async (req, res) => {
    const { fullName, email, password } = req.body;

    // Generate a random 6-digit verification code
    const verificationCode = Math.floor(100000 + Math.random() * 900000);

    // Save user status as unverified
    pendingUsers.push({ fullName, email, password, verificationCode, verified: false });

    // Email content options
    const mailOptions = {
        from: 'your-real-email@gmail.com',
        to: email,
        subject: 'Family Health - Verify Your Account',
        html: `
            <div style="font-family: Arial, sans-serif; padding: 20px; color: #333;">
                <h2 style="color: #4ab0e6;">Welcome to Family Health, ${fullName}!</h2>
                <p>Thank you for registering. Please use the verification code below to activate your account:</p>
                <div style="background: #f4f6f9; padding: 15px; font-size: 24px; font-weight: bold; text-align: center; letter-spacing: 5px; color: #2a8cc4; border-radius: 8px; margin: 20px 0;">
                    ${verificationCode}
                </div>
                <p>If you didn't request this, please ignore this email.</p>
            </div>
        `
    };

    try {
        // Send the real email
        await transporter.sendMail(mailOptions);
        res.status(200).json({ success: true, message: 'Verification email sent successfully!' });
    } catch (error) {
        console.error('Error sending email:', error);
        res.status(500).json({ success: false, message: 'Failed to send verification email.' });
    }
});

// Start server on port 3000
app.listen(3000, () => {
    console.log('Server running on http://localhost:3000');
});