// Navigation management function
function navigateTo(viewId) {
    // Hide all views
    const views = document.querySelectorAll('.view');
    views.forEach(view => view.classList.remove('active'));

    // Show target view
    const targetView = document.getElementById(`view-${viewId}`);
    if (targetView) {
        targetView.classList.add('active');
    }

    // Update bottom nav active state
    const navItems = document.querySelectorAll('.nav-item');
    navItems.forEach(item => item.classList.remove('active'));

    // Map view to nav index
    const navMap = {
        'home': 0,
        'gpservices': 1,
        'prescriptions': 2,
        'appointments': 3,
        'about': 4
    };

    if (navMap[viewId] !== undefined && navItems[navMap[viewId]]) {
        navItems[navMap[viewId]].classList.add('active');
    }

    // Scroll main container back to top
    document.getElementById('main-content').scrollTop = 0;
}

// Modal management functions
function openModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.add('active');
    }
}

function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.remove('active');
    }
}

// Toast feedback notification
function showToast(message) {
    const toast = document.getElementById('toast');
    toast.textContent = message;
    toast.classList.add('show');
    setTimeout(() => {
        toast.classList.remove('show');
    }, 3000);
}

// Handle form submissions & interactions
function handleFormSubmit(event, modalId, successMessage) {
    event.preventDefault();
    closeModal(modalId);
    showToast(successMessage);
}

// Event Listeners setup when DOM is fully loaded
document.addEventListener('DOMContentLoaded', () => {
    // Auth tab switching (Login / Register)
    const tabBtns = document.querySelectorAll('.tab-btn');
    tabBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            tabBtns.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');

            const targetFormId = btn.getAttribute('data-tab');
            document.querySelectorAll('.form-box').forEach(box => box.classList.remove('active'));
            document.getElementById(targetFormId).classList.add('active');
        });
    });

    // Login form submission -> navigates to Home view
    const loginForm = document.getElementById('login-form');
    if (loginForm) {
        loginForm.addEventListener('submit', (e) => {
            e.preventDefault();
            showToast('Login successful!');
            setTimeout(() => {
                navigateTo('home');
            }, 600);
        });
    }

    // Register form submission
    const registerForm = document.getElementById('register-form');
    if (registerForm) {
        registerForm.addEventListener('submit', (e) => {
            e.preventDefault();
            showToast('Account created successfully!');
            setTimeout(() => {
                navigateTo('home');
            }, 600);
        });
    }

    // Close modals when clicking outside modal content
    window.addEventListener('click', (e) => {
        if (e.target.classList.contains('modal')) {
            e.target.classList.remove('active');
        }
    });
});