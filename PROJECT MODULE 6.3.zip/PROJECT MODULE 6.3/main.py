from fastapi import FastAPI
from sqlalchemy import text
 
from database import engine
 
app = FastAPI()
 
 
@app.get("/")
def home():
    return {"message": "Medication Reminder API is running"}
 
 
@app.get("/database-test")
def test_database():
    with engine.connect() as connection:
        result = connection.execute(
            text("SELECT 1")
        ).scalar_one()
 
    return {
        "message": "Connected to MySQL successfully",
        "result": result,
    }
 
 
@app.get("/medications")
def get_medications():
    query = text("""
        SELECT
            medication_id,
            user_id,
            name,
            dosage_instructions
        FROM medications
        ORDER BY medication_id
    """)
 
    with engine.connect() as connection:
        rows = connection.execute(query).mappings().all()
 
    return [dict(row) for row in rows]
 