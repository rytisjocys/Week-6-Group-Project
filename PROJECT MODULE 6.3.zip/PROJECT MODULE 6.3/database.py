import os
from pathlib import Path
 
from dotenv import load_dotenv
from sqlalchemy import URL, create_engine
 
load_dotenv(Path(__file__).resolve().parent / ".env")
 
database_url = URL.create(
    drivername="mysql+pymysql",
    username=os.environ["DB_USER"],
    password=os.environ["DB_PASSWORD"],
    host=os.environ["DB_HOST"],
    port=int(os.environ["DB_PORT"]),
    database=os.environ["DB_NAME"],
    query={"charset": "utf8mb4"},
)
 
DATABASE_URL = "mysql+pymysql://root:admin@localhost:3306/medication_reminder1"

engine = create_engine(

    DATABASE_URL,

    pool_pre_ping=True,

)